using System;
using System.Collections.Generic;
using Kope.EntityIdentity;
using Kope.Feature.PathFindingOld.Node;
using Kope.Feature.PathFindingOld.PathFinding;
using Project.Scripts.Features.PathFindingOld.GraphManager;
using ThirdParty.PriorityQueeu;
using UnityEngine;

namespace Kope.Feature.PathFindingOld.Algorithms {

	public class AStarMicro {

		private static readonly List<Vec2Int> EMPTY_PATH = new();

		// NOTE: this table is exclusively for estimating H-cost (distance-to-goal). It must never be
		// used to price an actual G-cost edge step — the previous version did exactly that (used
		// whichever heuristic function was configured to price real movement), which meant an edge's
		// actual cost silently changed depending on the selected CostCalculationType instead of
		// reflecting real move geometry. See RelaxNeighbor below for the fix: G-cost is now always
		// priced from MicroGridNode.DIRECT_COST/DIAGONAL_COST based on the actual move, never from
		// this table.
		private readonly Dictionary<CostCalculationType, Func<Vec2Int, Vec2Int, int>> _costCalculators = new() {
			{ CostCalculationType.Manhattan, MicroGridNode.ManhattanCost },
			{ CostCalculationType.Euclidean, MicroGridNode.EuclideanCost },
			{ CostCalculationType.Octile, MicroGridNode.OctileCost }
		};

		private int _maxIterations = 10;
		private PathFindingConfig _config;

		private readonly IPathfindingGraphManager _graphManager;
		private readonly Dictionary<Vec2Int, MicroPathFindingNode> _nodeRecords;
		private readonly HashSet<Vec2Int> _closedSet;
		private readonly QuadPriorityQueue<MicroPathFindingNode, int> _openSet;

		private int _totalNodesCache;

		#region Buffers for Zero-Allocation Neighbor Expansion
		private readonly MicroGridNode[] _fetchBuffer = new MicroGridNode[8];
		private readonly MicroGridNode[] _neighbourBuffer = new MicroGridNode[8];
		#endregion

#if UNITY_EDITOR
		/// <summary>
		/// Reusable buffer for editor visualization tools. Stripped out completely in standalone builds.
		/// </summary>
		private readonly List<Vec2Int> _recorderOpenListCache = new(PathFindingConfig.DEFAULT_INITIAL_CAPACITY);
#endif

		public AStarMicro(
			IPathfindingGraphManager graphManager,
			PathFindingConfig config = default) {
			this._graphManager = graphManager;
			this._nodeRecords = new Dictionary<Vec2Int, MicroPathFindingNode>(config.InitialCapacity);
			this._closedSet = new HashSet<Vec2Int>(config.InitialCapacity);
			this._openSet = new QuadPriorityQueue<MicroPathFindingNode, int>(config.InitialCapacity);

			this._config = config;
		}

		public bool PreCheck(Vec2Int start, Vec2Int end, MovementCapability _, out MicroPathFindingResult preCheckResult) {
			this._totalNodesCache = this._graphManager.MicroNodeCount;

			bool TryValidateNode(Vec2Int pos, string pointLabel, out MicroGridNode nodeCache) {
				if (!this._graphManager.TryGetMicroNode(pos, out nodeCache)) {
					Debug.LogWarning($"[{pointLabel}] Position {pos} is not a valid micro node in the graph.");
					return false;
				}

				if (nodeCache.IsStaticObstacle) {
					Debug.LogWarning($"[{pointLabel}] Node at {pos} cannot be used for pathfinding (IsStaticObstacle: {nodeCache.IsStaticObstacle}).");
					return false;
				}

				return true;
			}

			if (!TryValidateNode(start, "Start", out var _) ||
				!TryValidateNode(end, "End", out var _)) {
				preCheckResult = CreateFailureResult(PathFindingResultType.InvalidStartOrEnd, 0, 0);
				return false;
			}

			preCheckResult = default;
			return true;
		}

		/// <summary>
		/// Finds a path from the specified start position to the end position using Weighted A*, with
		/// no corridor restriction. Use this over the corridor-restricted overload when you don't need
		/// tile-set filtering — it skips the per-neighbor corridor membership check entirely rather
		/// than just short-circuiting it.
		/// </summary>
		public MicroPathFindingResult FindPath(
			Vec2Int start, Vec2Int end,
			MicroPathfindingRecorder recorder = null) {

			MicroPathFindingNode _ = BeginSearch(
				start, end, recorder,
				out CostCalculationType costCalculationType, out float greedyNess,
				out bool useGreediness, out Func<Vec2Int, Vec2Int, int> costCalculator
			);

			int totalExpansion = 0;
			int totalNodeEvaluation = 0;

			while (this._openSet.Count > 0 && totalNodeEvaluation < this._maxIterations) {
				totalNodeEvaluation++;
				MicroPathFindingNode currentRecord = this._openSet.Dequeue();

#if UNITY_EDITOR
				RecordStep(recorder, currentRecord);
#endif

				if (currentRecord.NodePosition == end) {
					return new MicroPathFindingResult(
						PathFindingResultType.Success, ReconstructPath(currentRecord),
						this._totalNodesCache, totalNodeEvaluation,
						totalExpansion, costCalculationType,
						greedyNess
					);
				}

				this._closedSet.Add(currentRecord.NodePosition);
				totalExpansion++;

				ReadOnlySpan<MicroGridNode> neighbors = this._graphManager.GetWalkableMicroNeighboringNodesWithRules(
					currentRecord.NodePosition,
					this._neighbourBuffer,
					this._fetchBuffer,
					out byte diagonalMask
				);

				for (int i = 0; i < neighbors.Length; i++) {
					ref readonly MicroGridNode neighborNode = ref neighbors[i];

					if (this._closedSet.Contains(neighborNode.Position)) {
						continue;
					}

					bool isDiagonal = (diagonalMask & (1 << i)) != 0;
					RelaxNeighbor(currentRecord, neighborNode, isDiagonal, end, costCalculator, greedyNess, useGreediness, ref totalNodeEvaluation);
				}
			}

			return CreateFailureResult(PathFindingResultType.NoPathFound, totalNodeEvaluation, totalExpansion);
		}

		/// <summary>
		/// Finds a path from the specified start position to the end position using Weighted A*,
		/// restricted to the corridor tile set. Identical to the unrestricted overload except each
		/// neighbor is additionally required to be a member of <paramref name="corridorsTileSet"/>;
		/// callers that don't need that restriction should use the other overload instead of passing
		/// a permissive set, so this check isn't paid for free.
		/// </summary>
		public MicroPathFindingResult FindPath(
			Vec2Int start, Vec2Int end, HashSet<Vec2Int> corridorsTileSet,
			MicroPathfindingRecorder recorder = null) {

			MicroPathFindingNode _ = BeginSearch(
				start, end, recorder,
				out CostCalculationType costCalculationType, out float greedyNess,
				out bool useGreediness, out Func<Vec2Int, Vec2Int, int> costCalculator
			);

			int totalExpansion = 0;
			int totalNodeEvaluation = 0;

			while (this._openSet.Count > 0 && totalNodeEvaluation < this._maxIterations) {
				totalNodeEvaluation++;
				MicroPathFindingNode currentRecord = this._openSet.Dequeue();

#if UNITY_EDITOR
				RecordStep(recorder, currentRecord);
#endif

				if (currentRecord.NodePosition == end) {
					return new MicroPathFindingResult(
						PathFindingResultType.Success, ReconstructPath(currentRecord),
						this._totalNodesCache, totalNodeEvaluation,
						totalExpansion, costCalculationType,
						greedyNess
					);
				}

				this._closedSet.Add(currentRecord.NodePosition);
				totalExpansion++;

				ReadOnlySpan<MicroGridNode> neighbors = this._graphManager.
				GetWalkableMicroNeighboringNodesWithRules(
					currentRecord.NodePosition,
					this._fetchBuffer,
					this._neighbourBuffer,
					out byte diagonalMask
				);

				for (int i = 0; i < neighbors.Length; i++) {
					ref readonly MicroGridNode neighborNode = ref neighbors[i];

					if (this._closedSet.Contains(neighborNode.Position)) {
						continue;
					}

					// Corridor-restricted variant only: skip anything outside the allowed tile set.
					if (!corridorsTileSet.Contains(neighborNode.Position)) {
						continue;
					}

					bool isDiagonal = (diagonalMask & (1 << i)) != 0;
					RelaxNeighbor(currentRecord, neighborNode, isDiagonal, end, costCalculator, greedyNess, useGreediness, ref totalNodeEvaluation);
				}
			}

			return CreateFailureResult(PathFindingResultType.NoPathFound, totalNodeEvaluation, totalExpansion);
		}

		/// <summary>
		/// Shared setup for both FindPath overloads: resets per-query state, resolves the configured
		/// cost calculator and greediness, and seeds the start node into the open set / node records.
		/// </summary>
		private MicroPathFindingNode BeginSearch(
			Vec2Int start,
			Vec2Int end,
			MicroPathfindingRecorder recorder,
			out CostCalculationType costCalculationType,
			out float greedyNess,
			out bool useGreediness,
			out Func<Vec2Int, Vec2Int, int> costCalculator) {

			this._nodeRecords.Clear();
			this._closedSet.Clear();
			this._openSet.Clear();

#if UNITY_EDITOR
			recorder?.Clear();
#endif

			this._maxIterations = Mathf.CeilToInt(this._config.MaxIterationRatio * this._totalNodesCache);

			costCalculationType = this._config.CostCalculationType;
			greedyNess = this._config.GreedyNess;

			// Hoisted out of the neighbor loop (previously re-evaluated as a float equality check on
			// every single neighbor visit) — it's config-constant for the whole search.
			useGreediness = greedyNess != PathFindingConfig.DEFAULT_GREEDINESS;

			costCalculator = this._costCalculators[costCalculationType];

			int rawInitialH = costCalculator(start, end);
			int weightedInitialH = useGreediness ? Mathf.FloorToInt(rawInitialH * greedyNess) : rawInitialH;

			MicroPathFindingNode startNode = new(start, 0, weightedInitialH, null);

			this._openSet.EnqueueOrUpdate(startNode);
			this._nodeRecords[start] = startNode;

			return startNode;
		}

		/// <summary>
		/// Prices one neighbor edge and, if unvisited or improved, updates its record and (re-)enqueues
		/// it. Shared by both FindPath overloads — the only thing that differs between them is whether
		/// a corridor-membership check runs before this is called.
		/// <para>
		/// G-COST: priced from <see cref="MicroGridNode.DIRECT_COST"/>/<see cref="MicroGridNode.DIAGONAL_COST"/>
		/// based on the actual move geometry (<paramref name="isDiagonal"/>), never from the configured
		/// heuristic distance function — that function estimates remaining distance to the goal (H-cost)
		/// only, and previously was being reused to price real edges, which made G-cost track whichever
		/// heuristic happened to be configured instead of the actual move.
		/// </para>
		/// </summary>
		private void RelaxNeighbor(
			MicroPathFindingNode currentRecord,
			MicroGridNode neighborNode,
			bool isDiagonal,
			Vec2Int end,
			Func<Vec2Int, Vec2Int, int> costCalculator,
			float greedyNess,
			bool useGreediness,
			ref int totalNodeEvaluation) {

			Vec2Int neighborPos = neighborNode.Position;

			int stepCost = isDiagonal ? MicroGridNode.DIAGONAL_COST : MicroGridNode.DIRECT_COST;
			int tentativeCost = currentRecord.GCost + stepCost;

			// Update node record if unvisited or if a cheaper path is discovered
			if (!this._nodeRecords.TryGetValue(neighborPos, out MicroPathFindingNode existingNeighborRecord)
				|| tentativeCost < existingNeighborRecord.GCost) {

				int rawHCost = costCalculator(neighborPos, end);
				int weightedHCost = useGreediness
					? Mathf.FloorToInt(rawHCost * greedyNess)
					: rawHCost;

				MicroPathFindingNode neighborRecord = new(
					neighborPos,
					tentativeCost,
					weightedHCost,
					currentRecord.NodePosition
				);

				this._nodeRecords[neighborPos] = neighborRecord;
				this._openSet.EnqueueOrUpdate(neighborRecord);
			}

			totalNodeEvaluation++;
		}

#if UNITY_EDITOR
		private void RecordStep(MicroPathfindingRecorder recorder, MicroPathFindingNode currentRecord) {
			if (recorder == null) {
				return;
			}

			this._recorderOpenListCache.Clear();
			foreach (var node in this._openSet.GetElements()) {
				this._recorderOpenListCache.Add(node.NodePosition);
			}
			recorder.RecordStep(currentRecord.NodePosition, this._recorderOpenListCache, this._closedSet);
		}
#endif

		private List<Vec2Int> ReconstructPath(MicroPathFindingNode current) {
			List<Vec2Int> totalPath = new() { current.NodePosition };

			while (current.Parent.HasValue) {
				Vec2Int parentPos = current.Parent.Value;
				totalPath.Add(parentPos);
				current = this._nodeRecords[parentPos];
			}

			totalPath.Reverse();
			return totalPath;
		}

		private MicroPathFindingResult CreateFailureResult(
			PathFindingResultType resultType, int totalNodeEvaluations, int totalNodeExpansions) {
			return new MicroPathFindingResult(
				resultType,
				EMPTY_PATH, this._totalNodesCache,
				totalNodeEvaluations, totalNodeExpansions,
				this._config.CostCalculationType, this._config.GreedyNess
			);
		}
	}
}