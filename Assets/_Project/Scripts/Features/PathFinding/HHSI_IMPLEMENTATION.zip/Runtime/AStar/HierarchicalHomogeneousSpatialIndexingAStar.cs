using System;
using System.Collections.Generic;
using Kope.EntityIdentity;
using Kope.Feature.PathFindingOld.Algorithms;
using Kope.Feature.PathFindingOld.Node;
using Kope.Feature.PathFindingOld.PathFinding;
using Project.Scripts.Features.PathFindingOld.GraphManager;

namespace Project.Scripts.Features.PathFindingOld.Algorithms {
	/// <summary>
	/// Hierarchical Homogeneous Spatial Indexing (HHSI) pathfinding.
	///
	/// Architecture:
	/// 1. Macro Layer
	///    - Operates on a compact graph of homogeneous regions.
	///    - Answers a reachability question:
	///          "Can a valid path exist between the start and goal?"
	///    - Rapidly rejects impossible queries before any expensive micro search begins.
	///    - Optionally produces a region-chain that can be used to construct a corridor.
	///
	/// 2. Micro Layer
	///    - Performs the actual tile-level A* search.
	///    - Responsible for generating the final movement path.
	///    - Can either search the full world or a corridor constrained by the macro result.
	///
	/// Unlike traditional hierarchical pathfinding systems where the macro graph is
	/// primarily responsible for route planning, HHSI uses the macro graph as a
	/// connectivity oracle and search-space reduction mechanism.
	///
	/// Primary Benefits:
	/// - O(1)-like rejection of disconnected start/end regions.
	/// - Prevents large-scale failed A* searches.
	/// - Reduces micro search space through corridor restriction when beneficial.
	/// - Maintains full tile-level path accuracy.
	///
	/// Example:
	/// If two points belong to disconnected macro regions, the macro layer can
	/// terminate the query immediately without launching a micro A* search,
	/// avoiding thousands of unnecessary node evaluations.
	/// </summary>
	public class HierarchicalHomogeneousSpatialIndexingAStar {
		/// <summary>
		/// The initial capacity of the corridor tile set. This is a performance optimization to reduce
		/// memory allocations during pathfinding, as corridor tiles are often reused across multiple searches.
		/// </summary>
		const int INITIAL_SET_CAPACITY = 256;
		private readonly IPathfindingGraphManager _graphManager;
		private readonly AStarMicro _microAStar;
		private readonly AStarMacro _macroAStar;
		private readonly HashSet<Vec2Int> corridorsTileSet;
		private readonly int _minimumCorridorSize;



		public HierarchicalHomogeneousSpatialIndexingAStar(
			IPathfindingGraphManager graphManager, PathFindingConfig microConfig,
			PathFindingConfig macroConfig, int minimumCorriderSize = 5
			) {
			this._graphManager = graphManager ?? throw new ArgumentNullException(nameof(graphManager));
			this._microAStar = new AStarMicro(graphManager, microConfig);
			this._macroAStar = new AStarMacro(graphManager, macroConfig);
			this.corridorsTileSet = new HashSet<Vec2Int>(INITIAL_SET_CAPACITY);
			this._minimumCorridorSize = minimumCorriderSize;
		}

		public PathFindingResultAggregate FindPath(
			Vec2Int start, Vec2Int end, MovementCapability entityMovementCapability,
			MacroPathfindingRecorder macroRecorder = null,
			MicroPathfindingRecorder microRecorder = null) {

			// 1. Macro Pre-Check
			if (!this._macroAStar.PreCheck(start, end, entityMovementCapability, out var macroPreCheckResult)) {
				return new PathFindingResultAggregate(PathFindingErrorPath.MacroPreCheck, macroPreCheckResult, null);
			}

			// 2. Micro Pre-Check
			if (!this._microAStar.PreCheck(start, end, entityMovementCapability, out var microPreCheckResult)) {
				return new PathFindingResultAggregate(PathFindingErrorPath.MicroPreCheck, macroPreCheckResult, microPreCheckResult);
			}

			// 3. Macro Search
			var macroPathFindingResult = this._macroAStar.FindPath(start, end, entityMovementCapability, macroRecorder);

			if (macroPathFindingResult.pathFindingResultType != PathFindingResultType.Success) {
				return new PathFindingResultAggregate(PathFindingErrorPath.MacroPathFinding, macroPathFindingResult, null);
			}

			bool requiresCorridor = macroPathFindingResult.Path.Count > this._minimumCorridorSize;

			if (requiresCorridor) {
				this.corridorsTileSet.Clear();
				this._graphManager.GetAllCorridorPositions(macroPathFindingResult.Path, this.corridorsTileSet);

			}


			// Ternary operator neatly handles the execution branch based on corridor requirement
			MicroPathFindingResult microResultFinal = requiresCorridor
				? this._microAStar.FindPath(start, end, this.corridorsTileSet, microRecorder)
				: this._microAStar.FindPath(start, end, microRecorder);


			//	Debug.Log($"Micro A* took {stopwatch.ElapsedMilliseconds} ms {stopwatch.ElapsedTicks} Ticks for pathfinding from {start} to {end}.");

			// 5. Final Result Verification
			if (microResultFinal.pathFindingResultType != PathFindingResultType.Success) {
				return new PathFindingResultAggregate(PathFindingErrorPath.MicroPathFinding, macroPathFindingResult, microResultFinal);
			}

			return new PathFindingResultAggregate(PathFindingErrorPath.None, macroPathFindingResult, microResultFinal);
		}

		public void InjectMicroConfig(PathFindingConfig config) { }
		public void InjectMacroConfig(PathFindingConfig config) { }
	}
}